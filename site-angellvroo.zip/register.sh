#!/usr/bin/env bash
# One-time: registers your GitHub Pages domain with Tesla's Fleet API.
# Safe to run again.
#
#   CLIENT_ID='paste-id' CLIENT_SECRET='paste-secret' ./register.sh
#   Or just run ./register.sh and it will ask you for the values.
#
# Optional: DOMAIN=other.github.io REGION=na (or eu)
set -euo pipefail

DOMAIN="${DOMAIN:-angellvroo.github.io}"
DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN%%/*}"

if [[ -z "${CLIENT_ID:-}" ]]; then
  read -r -p "Client ID (from developer.tesla.com → your app → Credentials): " CLIENT_ID
fi
if [[ -z "${CLIENT_SECRET:-}" ]]; then
  read -r -s -p "Client Secret (typing is hidden): " CLIENT_SECRET
  echo
fi
if [[ -z "${CLIENT_ID:-}" || -z "${CLIENT_SECRET:-}" ]]; then
  echo "Client ID and Client Secret are required."
  exit 1
fi

if [[ -z "${REGION:-}" ]]; then
  echo "Which region is your Tesla account in?"
  echo "  1) North America / Asia-Pacific   (US, Canada, Mexico, Asia-Pacific)"
  echo "  2) Europe / Middle East / Africa"
  read -r -p "Type 1 or 2, then press Return: " choice
  case "$choice" in
    2|eu|EU|e|E) REGION=eu ;;
    *) REGION=na ;;
  esac
fi

case "$REGION" in
  na) API="https://fleet-api.prd.na.vn.cloud.tesla.com" ;;
  eu) API="https://fleet-api.prd.eu.vn.cloud.tesla.com" ;;
  *) echo "REGION must be na or eu"; exit 1 ;;
esac

AUTH="https://fleet-auth.prd.vn.cloud.tesla.com/oauth2/v3/token"
KEY_URL="https://$DOMAIN/.well-known/appspecific/com.tesla.3p.public-key.pem"

echo "1/4  Checking the public key is online: $KEY_URL"
if ! curl -fsS "$KEY_URL" | grep -q "BEGIN PUBLIC KEY"; then
  echo "     Not found yet. Upload the site files to GitHub Pages and wait a minute, then try again."
  exit 1
fi

echo "2/4  Getting a partner token"
RESP=$(curl -sS -X POST "$AUTH" -H 'Content-Type: application/x-www-form-urlencoded' \
  --data-urlencode grant_type=client_credentials \
  --data-urlencode "client_id=$CLIENT_ID" \
  --data-urlencode "client_secret=$CLIENT_SECRET" \
  --data-urlencode "scope=openid vehicle_device_data vehicle_cmds vehicle_charging_cmds" \
  --data-urlencode "audience=$API")
TOKEN=$(printf '%s' "$RESP" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("access_token",""))' 2>/dev/null || true)
[[ -n "$TOKEN" ]] || { echo "     Failed: $RESP"; exit 1; }

echo "3/4  Registering $DOMAIN in $API"
curl -sS -X POST "$API/api/1/partner_accounts" -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d "{\"domain\":\"$DOMAIN\"}"
echo

echo "4/4  Asking Tesla which key it has for $DOMAIN"
curl -sS "$API/api/1/partner_accounts/public_key?domain=$DOMAIN" -H "Authorization: Bearer $TOKEN"
echo
echo "Done. If step 3 shows your client_id and domain, go back to the app and sign in with Tesla."
